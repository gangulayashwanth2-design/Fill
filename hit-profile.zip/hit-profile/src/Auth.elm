module Auth exposing (Model, Msg(..), User, init, update)


type alias User =
    { username : String
    , email : String
    }


type Msg
    = SignedIn User
    | SignedOut


type alias Model =
    { user : Maybe User }


init : Model
init =
    { user = Nothing }


update : Msg -> Model -> Model
update msg model =
    case msg of
        SignedIn user ->
            { model | user = Just user }

        SignedOut ->
            { model | user = Nothing }
