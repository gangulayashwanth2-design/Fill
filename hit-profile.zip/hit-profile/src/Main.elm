module Main exposing (main)

import Auth
import Browser
import Html exposing (Html, div, text)
import Html.Attributes exposing (class)
import Profile


type alias Model =
    { auth : Auth.Model
    , profile : Profile.Model
    , page : Page
    }


type Page
    = ProfilePage
    | LoginPage


type Msg
    = ProfileMsg Profile.Msg
    | AuthMsg Auth.Msg
    | NavigateTo Page


init : () -> ( Model, Cmd Msg )
init _ =
    let
        authModel =
            Auth.init

        -- For demonstration, start logged in as a sample user.
        demoUser =
            { username = "yashwanth"
            , email = "yashwanth@example.com"
            }

        authWithUser =
            Auth.update (Auth.SignedIn demoUser) authModel

        profileModel =
            Profile.init authWithUser.user
    in
    ( { auth = authWithUser
      , profile = profileModel
      , page = ProfilePage
      }
    , Cmd.none
    )


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        ProfileMsg profileMsg ->
            let
                ( newProfile, _, maybeAuthMsg ) =
                    Profile.update profileMsg model.profile
            in
            case maybeAuthMsg of
                Just authMsg ->
                    let
                        newAuth =
                            Auth.update authMsg model.auth
                    in
                    ( { model
                        | profile = Profile.init newAuth.user
                        , auth = newAuth
                        , page = LoginPage
                      }
                    , Cmd.none
                    )

                Nothing ->
                    ( { model | profile = newProfile }, Cmd.none )

        AuthMsg authMsg ->
            let
                newAuth =
                    Auth.update authMsg model.auth
            in
            ( { model
                | auth = newAuth
                , profile = Profile.init newAuth.user
              }
            , Cmd.none
            )

        NavigateTo page ->
            ( { model | page = page }, Cmd.none )


view : Model -> Html Msg
view model =
    case model.page of
        ProfilePage ->
            Html.map ProfileMsg (Profile.view model.profile)

        LoginPage ->
            div [ class "login-container" ]
                [ text "Login page (not implemented in this component)" ]


main : Program () Model Msg
main =
    Browser.element
        { init = init
        , update = update
        , view = view
        , subscriptions = \_ -> Sub.none
        }
