module Profile exposing (Model, Msg(..), init, update, view)

import Auth exposing (User)
import Html exposing (Html, button, div, h1, input, label, text)
import Html.Attributes exposing (class, placeholder, type_, value)
import Html.Events exposing (onClick, onInput)


type alias Model =
    { user : Maybe User
    , editing : Bool
    , username : String
    }


type Msg
    = EditUsername
    | UpdateUsername String
    | SaveUsername
    | Logout


init : Maybe User -> Model
init maybeUser =
    case maybeUser of
        Just user ->
            { user = Just user
            , editing = False
            , username = user.username
            }

        Nothing ->
            { user = Nothing
            , editing = False
            , username = ""
            }


update : Msg -> Model -> ( Model, Cmd Msg, Maybe Auth.Msg )
update msg model =
    case msg of
        EditUsername ->
            ( { model | editing = True }, Cmd.none, Nothing )

        UpdateUsername newUsername ->
            ( { model | username = newUsername }, Cmd.none, Nothing )

        SaveUsername ->
            let
                updatedUser =
                    Maybe.map
                        (\u -> { u | username = model.username })
                        model.user
            in
            ( { model | user = updatedUser, editing = False }
            , Cmd.none
            , Nothing
            )

        Logout ->
            ( model, Cmd.none, Just Auth.SignedOut )


view : Model -> Html Msg
view model =
    case model.user of
        Just user ->
            div [ class "profile-container" ]
                [ h1 [] [ text "Profile" ]
                , div [ class "profile-field" ]
                    [ label [] [ text "User:" ]
                    , text " "
                    , text user.username
                    ]
                , div [ class "profile-field" ]
                    [ label [] [ text "Email:" ]
                    , text " "
                    , text user.email
                    ]
                , if model.editing then
                    div [ class "profile-edit" ]
                        [ label [] [ text "New username:" ]
                        , input
                            [ type_ "text"
                            , placeholder "Enter new username"
                            , value model.username
                            , onInput UpdateUsername
                            ]
                            []
                        , button
                            [ class "btn-primary"
                            , onClick SaveUsername
                            ]
                            [ text "Save" ]
                        ]

                  else
                    button
                        [ class "btn-secondary"
                        , onClick EditUsername
                        ]
                        [ text "Edit" ]
                , button
                    [ class "btn-danger"
                    , onClick Logout
                    ]
                    [ text "Logout" ]
                ]

        Nothing ->
            div [ class "profile-container" ]
                [ h1 [] [ text "Profile" ]
                , text "You are not logged in. Redirecting to Login..."
                ]
