# HIT Profile Component

This repository contains the Profile frontend component for the Habits and Intention Tracker (HIT) project, implemented in Elm 0.19.1.

## What This Is

The Profile component lets an authenticated user:

- View their username and email.
- Enter edit mode to change their username.
- Save the new username to the local model.
- Log out.

If the user is not authenticated, the component shows a message and the parent application redirects to the login page.

## What This Is Not

This is not the full HIT application. It is only the Profile component, with a minimal application shell (`Main.elm`) and a mock authentication module (`Auth.elm`) so that the component can be run independently.

The component does not persist username changes to a backend. The username change is saved to the local Elm model only, and it is lost when the page is reloaded.

## Prerequisites

- Node.js
- Elm 0.19.1

## Setup

```bash
npm install -g elm elm-live
git clone https://github.com/<your-username>/hit-profile.git
cd hit-profile
elm make src/Main.elm --output=elm.js
elm-live src/Main.elm --open -- --output=elm.js
```

The browser opens automatically. If it does not, go to the URL shown in the terminal (usually http://localhost:8000).

## Project Structure

```text
hit-profile/
├── elm.json
├── index.html
├── README.md
└── src/
    ├── Main.elm      -- application shell and page routing
    ├── Profile.elm   -- the Profile component (model, update, view)
    └── Auth.elm      -- mock shared authentication state
```

## Testing

Manual test cases are described in the dissertation. There are no automated tests.

## Known Limitations

- No backend persistence for username changes.
- No input validation (empty usernames allowed).
- No automated tests.
- No accessibility audit.
- No user evaluation.

## Author

Yashwanth Reddy Gangula
